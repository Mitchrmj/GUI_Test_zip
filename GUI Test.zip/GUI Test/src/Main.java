public class Main {

    public static void main(String[] args) {

        System.out.println("SEQUENCE: main started");
        GUI gui = new GUI();
        System.out.println("SEQUENCE: main finished");
    }


}
